import './Bloglist.css'

const Bloglist = (props) => {
        let Delete=props.Data;
        let blogs=props.mapdata;

    return ( 
        blogs.map((data)=>(
            <div className="blogs-preview">
                <h3>{data.sid}</h3>
                <h3>{data.sname}</h3>
                <p>Total Marks {data.totalm}</p>
                <button onClick={ ()=>Delete(data.id) }>Delete</button>
            </div>
        ))

     );
}
 
export default Bloglist;