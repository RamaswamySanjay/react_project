import React from 'react'
import { useState } from 'react'

function UseState() {
let [count,setCount] =useState(0)

    let handleClick =()=>{
        setCount(count+1)
         console.log("You clicked.....!"+count++);
        
    }
    let decrease=()=>{
        setCount(--count)
    }
    let reset= ()=>{
        setCount(count=0)
    }

    return (
        <div>
            <h1>{count}</h1>
            <button onClick={handleClick}>increase</button>
            <button onClick={reset}>reset</button>
            <button onClick={decrease}>decrease</button>
        </div>
    )
}

export default UseState
