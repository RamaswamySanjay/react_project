import { useState, useEffect } from "react/cjs/react.development";
import Bloglist from "./Bloglist";

const Fetch = () => {
  let [blogs, setBlogs] = useState([]);

  let handleDelete = (id) => {
    let newBlogs = blogs.filter((blog) => blog.id !== id);
    setBlogs(newBlogs);
  };

  useEffect(() => {
      fetch("  http://localhost:3000/posts")
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          setBlogs(data);
        });
  }, []);

  return (
    <div className="home">
      <Bloglist data={blogs} title="All Blogs" func={handleDelete} />
    </div>
  );
};
export default Fetch;
