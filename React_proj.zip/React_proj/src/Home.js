import { useState,useEffect } from "react";
import Bloglist from "./Bloglist";




const Home = () => {
    let [blogs, setBlogs] = useState([]);
//     let [blogs,setBlogs]=useState(
    
//         [
//         {title:"my first blog",author:"Ross",id:1},
//         {title:"spiderman",author:"stan lee",id:2},
//         {title:"harry Potter",author:"j.k rollins",id:3},
//         {title:"the mahabarath secrets", author:"cristopher c doyel",id:4},
//         {title:"Dr Strange",author:"stan lee",id:5},

// ]
// )

useEffect(() => {
    fetch(" http://localhost:3000/posts")
      .then((res) => {
        return res.json();
      })
      .then((data) => {
        setBlogs(data);
      });
}, []);

  
let Delete=(id)=>{
    let newBlogs =blogs.filter((blog)=>blog.id!==id)
    setBlogs(newBlogs)
}

    return ( 
            <>    
            {/* <Bloglist mapdata={blogs}/> */}
                {/* to display perticular data inside an array */}
                <h1>Students record</h1>
            <Bloglist mapdata={blogs} Data={Delete} />
            </>
     );
}
 
export default Home;