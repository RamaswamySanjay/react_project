import './Create.css'
import { useState } from 'react';
import { useHistory } from 'react-router-dom';


function Create() {
    let [sid, setTitle] = useState()
    let [sname, setName] = useState()
    let [totalm,setTotal]= useState();
    let his=useHistory()

    let handleSubmit=(e)=>{
        e.preventDefault();
        let blog={sid,sname,totalm}
        console.log(blog);
        fetch(" http://localhost:3000/posts",{
            method:"POST",
            headers:{"content-type":"application/json"},
            body:JSON.stringify(blog)
        }).then(()=>{alert('data are added...') 
        his.push('/create')})
    }

    return (
        <div className="create">
            <h2>Add New Students data</h2>
            <div className="form">
                <form action="" onSubmit={handleSubmit}>
                    <label>Student_id</label><br />
                    <input type="text" value={sid} onChange={(e) => setTitle(e.target.value)} /><br/>
                    <label>Student_Name</label><br />
                    <input type="text" value={sname} onChange={(e) => setName(e.target.value)} /><br/>
                    <label>total_marks</label><br />
                    <input type="text" value={totalm} onChange={(e) => setTotal(e.target.value)}/><br />
                    <button>Add Data</button>
                </form>
            </div>
        </div>
    );
}

export default Create;