const Samp = () => {
    return ( <h1>hello</h1> );
}
 
export default Samp;