import { Link } from 'react-router-dom';
import './Navbar.css'

const Navbar = () => {

    return ( 
        <div className="Nav">
            <Link to="/create" style={{textDecoration:'none'}}><h1>Students List</h1></Link>
            <div className="link">
            {/* <a href="/create">Home</a>
            <a href="/">New Blog</a> */}
            <div className="link1">
              <Link to="/create" style={{textDecoration:'none'}} className='l1'>Home</Link>
            </div>
            <div className="link2">
               <Link to="/" style={{textDecoration:'none'}} className='l2'>New data</Link>
            </div>
           
            
            </div>
            
        </div>
     );
}
 
export default Navbar;