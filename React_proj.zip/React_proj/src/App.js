import './App.css'
import Home from './Home';
import Navbar from './Navbar';
import { BrowserRouter as Router,Route,Switch } from "react-router-dom/cjs/react-router-dom.min";
import Create from './Create';




function App() {
  return (
    <Router>
    <div className='App'>
      {/* <UseState/> */}
      <Navbar />
      <div className="content">
      <Switch>
      <Route path="/" exact/>
      <Home />
      </Switch>
      <Switch>
      <Route path="/create" exact />
      <Create/>
      </Switch>
      </div>
      </div>
      </Router>
  );
}

export default App;


